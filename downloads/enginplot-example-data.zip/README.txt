PlotIt example data
====================

All files here are synthetic, generated for testing PlotIt — none of it is
real recorded or proprietary data.

csv/automotive_*.csv
    Six synthetic automotive field-test scenarios (braking, constant speed,
    hilly terrain, lane change, launch, rough road), 20 channels each at
    100 Hz for 10 s. Good for trying Overlay, Stacked, and Stacked-by-Unit
    layouts, and the automatic dual Y-axis.

csv/comments_and_header.csv, inline_units_brackets.csv,
csv/inline_units_parens.csv, names_and_units_rows.csv,
csv/names_only_header.csv, no_header.csv
    Small hand-built files exercising PlotIt's CSV header/unit detection —
    comment lines, inline units in brackets or parentheses, a separate
    units row, names-only headers, and no header at all.

rpc/pathological_small.tim
    Twenty channels deliberately built with NaNs, infinities, subnormal
    values, and out-of-range magnitudes, to show off the data-quality
    indicators in the file tree.

Get PlotIt: https://gitlab.com/ArchWoodCode/win32app
