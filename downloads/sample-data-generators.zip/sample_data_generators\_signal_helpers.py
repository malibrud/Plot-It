"""
Small numeric helpers shared by the generator scripts in this directory.
Not a public API -- just factored out of gen_perf_road_load.py so the other
scripts don't each reimplement the same few lines.
"""

import numpy as np


def moving_average(x, w):
    """Box moving average of window w, O(N) via cumulative sum (float64)."""
    c = np.cumsum(np.concatenate(([0.0], x)), dtype=np.float64)
    out = np.empty_like(x, dtype=np.float64)
    half = w // 2
    n = x.size
    i = np.arange(n)
    lo = np.clip(i - half, 0, n)
    hi = np.clip(i - half + w, 0, n)
    out[:] = (c[hi] - c[lo]) / np.maximum(hi - lo, 1)
    return out


def lowpass(x, w):
    """Two cascaded box filters ~ triangular window: a gentler low pass."""
    return moving_average(moving_average(x, w), w)


def second_difference(x, h, dt):
    """Central second derivative with a stride of h samples (also a mild low pass).
    Stride keeps the differences well above float round-off for smooth signals."""
    d = np.empty_like(x, dtype=np.float64)
    d[h:-h] = (x[2 * h:] - 2.0 * x[h:-h] + x[:-2 * h]) / (h * dt) ** 2
    d[:h] = d[h]
    d[-h:] = d[-h - 1]
    return d


def first_difference(x, h, dt):
    d = np.empty_like(x, dtype=np.float64)
    d[h:-h] = (x[2 * h:] - x[:-2 * h]) / (2.0 * h * dt)
    d[:h] = d[h]
    d[-h:] = d[-h - 1]
    return d


def to_rms(x, target):
    """Scale a zero-mean signal to a target RMS (keeps the shape, sets the level)."""
    return x * (target / x.std())
