"""
Generate synthetic automotive field-test CSV files for PlotIt: six common
proving-ground maneuvers sharing one 21-channel schema (driver inputs, body
motion, GPS, and corner/suspension response).

10 s @ 100 Hz per file (1000 rows). All scenarios use the same simple vehicle
model (bicycle-model lateral dynamics, a filtered-noise road input for
suspension/wheel-force response, roll/pitch coupled off Ay/Ax) driven by a
per-scenario pedal/steer/speed script, so the six files read as one
consistent test vehicle doing different things rather than six unrelated
data sets.

Usage:
    python gen_automotive_csv.py                       # writes all six
    python gen_automotive_csv.py --scenario launch      # writes just one
    python gen_automotive_csv.py --scenario launch out.csv
"""

import argparse
import numpy as np
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _signal_helpers import lowpass, first_difference, second_difference

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "..", "examples", "csv")

DT = 0.01
N = 1000
G = 9.81
WHEELBASE = 2.7            # m
STATIC_LOAD = 4050.0       # N, front-corner static wheel load
ROLL_GAIN = 3.5            # deg of roll per g of lateral accel
PITCH_GAIN = 2.5           # deg of pitch per g of longitudinal accel
LAT0, LON0, ALT0 = 42.5, -83.2, 220.0   # proving-ground origin

COLUMNS = [
    "Time", "Throttle", "Brake", "Steer", "Speed", "Ax", "Ay", "Az",
    "RollRate", "PitchRate", "YawRate", "GPS_Lat", "GPS_Lon", "GPS_Alt",
    "SprungAcc_F", "UnsprungAcc_FL", "UnsprungAcc_FR", "SuspDisp_FL",
    "SuspDisp_FR", "WheelForce_FL", "Strain_LCA",
]
UNITS = [
    "s", "%", "bar", "deg", "km/h", "g", "g", "g", "deg/s", "deg/s",
    "deg/s", "deg", "deg", "m", "m/s^2", "m/s^2", "m/s^2", "mm", "mm",
    "N", "ustrain",
]


def smooth_interp(t, waypoints, w=15):
    """Piecewise-linear waypoints -> a lowpass-smoothed trace (no sharp kinks)."""
    wp_t = np.array([p[0] for p in waypoints], dtype=np.float64)
    wp_v = np.array([p[1] for p in waypoints], dtype=np.float64)
    raw = np.interp(t, wp_t, wp_v)
    return lowpass(raw, w)


def smoothed_noise(rng, w, target_std):
    """Low-frequency noise (driver correction, not 100 Hz jitter), at a set RMS."""
    x = lowpass(rng.standard_normal(N), w)
    return x * (target_std / x.std())


# --------------------------------------------------------------- scenarios
def scenario_launch(t, rng):
    v_kph = smooth_interp(t, [(0, 0), (1, 5), (2, 20), (3, 42), (4, 62),
                               (5, 78), (6, 90), (7, 98), (8, 103), (10, 106)], w=25)
    throttle = smooth_interp(t, [(0, 4), (1, 15), (2, 45), (3, 70), (4, 88),
                                  (5, 95), (6, 98), (7, 100), (10, 100)], w=15)
    brake = np.zeros(N)
    steer = smoothed_noise(rng, 20, 0.15)
    return dict(
        v_kph=v_kph, throttle=throttle, brake=brake, steer=steer,
        roughness_mm=2.0, washboard=False, hills=False,
        comment="Launch: standstill to ~100 km/h, wide-open throttle, ~0.7 g, weight transfer rearward.",
    )


def scenario_braking(t, rng):
    # 108 km/h (30 m/s) to 0 over ~3.8 s of hard braking is ~0.8 g average.
    v_kph = smooth_interp(t, [(0, 108), (3.0, 108), (3.2, 108), (7.0, 0),
                               (7.3, 0), (10, 0)], w=25)
    throttle = smooth_interp(t, [(0, 20), (3.0, 20), (3.2, 0), (10, 0)], w=15)
    brake = smooth_interp(t, [(0, 0), (3.2, 0), (3.5, 72), (7.0, 72),
                               (7.3, 0), (10, 0)], w=15)
    steer = smoothed_noise(rng, 20, 0.15)
    return dict(
        v_kph=v_kph, throttle=throttle, brake=brake, steer=steer,
        roughness_mm=2.0, washboard=False, hills=False,
        comment="Braking: ~108 km/h to stop at ~0.8 g, forward weight transfer / nose dive.",
    )


def scenario_constant_speed(t, rng):
    v_kph = smooth_interp(t, [(0, 98), (10, 101)], w=25) + 0.3 * rng.standard_normal(N)
    v_kph = lowpass(v_kph, 20)
    throttle = smooth_interp(t, [(0, 24), (10, 27)], w=25) + 0.4 * rng.standard_normal(N)
    brake = np.zeros(N)
    steer = smoothed_noise(rng, 20, 0.08)
    return dict(
        v_kph=v_kph, throttle=throttle, brake=brake, steer=steer,
        roughness_mm=1.0, washboard=False, hills=False,
        comment="Constant-speed cruise at ~100 km/h on smooth pavement (quiet baseline).",
    )


def scenario_hilly_terrain(t, rng):
    # Rolling grade, +/-30 m of elevation over the clip. Speed and throttle are
    # authored directly (in phase/out of phase with the grade) rather than
    # derived by differentiating the altitude trace, which amplifies noise
    # into unrealistic g-forces for a gentle rolling road.
    alt_extra = 15.0 * np.sin(2.0 * np.pi * t / 6.0) + 8.0 * np.sin(2.0 * np.pi * t / 13.0 + 1.0)
    grade_phase = np.sin(2.0 * np.pi * t / 6.0 + 0.35) + 0.5 * np.sin(2.0 * np.pi * t / 13.0 + 1.35)
    v_kph = 80.0 - 9.0 * grade_phase + 0.3 * rng.standard_normal(N)
    v_kph = lowpass(v_kph, 15)
    throttle = 34.0 + 16.0 * grade_phase + 0.5 * rng.standard_normal(N)
    throttle = np.clip(lowpass(throttle, 15), 5.0, 100.0)
    brake = np.zeros(N)
    steer = smoothed_noise(rng, 20, 0.13)
    return dict(
        v_kph=v_kph, throttle=throttle, brake=brake, steer=steer,
        roughness_mm=2.5, washboard=False, hills=True, alt_extra=alt_extra,
        comment="Hilly terrain: rolling grade +/-30 m, speed and throttle track the slope.",
    )


def scenario_lane_change(t, rng):
    v_kph = smooth_interp(t, [(0, 78), (10, 81)], w=25) + 0.3 * rng.standard_normal(N)
    v_kph = lowpass(v_kph, 20)
    throttle = smooth_interp(t, [(0, 30), (10, 32)], w=25) + 0.3 * rng.standard_normal(N)
    brake = np.zeros(N)
    # ISO-3888-style double lane change: one sine period gives a left pulse
    # then an opposite right pulse; a raised-cosine window keeps the ends at 0.
    t0, T = 3.6, 1.8
    window = np.where((t >= t0) & (t <= t0 + T), np.sin(np.pi * (t - t0) / T), 0.0)
    steer = 2.2 * np.sin(2.0 * np.pi * (t - t0) / T) * window
    steer += smoothed_noise(rng, 20, 0.08)
    return dict(
        v_kph=v_kph, throttle=throttle, brake=brake, steer=steer,
        roughness_mm=2.0, washboard=False, hills=False,
        comment="Double lane change at ~80 km/h, ~0.5 g lateral, body roll and yaw.",
    )


def scenario_rough_road(t, rng):
    v_kph = smooth_interp(t, [(0, 30), (1.5, 47), (10, 45)], w=20) + 0.6 * rng.standard_normal(N)
    v_kph = lowpass(v_kph, 15)
    throttle = smooth_interp(t, [(0, 25), (1.5, 36), (10, 36)], w=20) + 1.0 * rng.standard_normal(N)
    brake = np.zeros(N)
    steer = smoothed_noise(rng, 15, 0.4)          # driver correcting for road disturbance
    return dict(
        v_kph=v_kph, throttle=throttle, brake=brake, steer=steer,
        roughness_mm=9.0, washboard=True, hills=False,
        comment="Rough secondary road at ~47 km/h: washboard + broadband, heavy wheel/suspension activity.",
    )


SCENARIOS = {
    "launch": scenario_launch,
    "braking": scenario_braking,
    "constant_speed": scenario_constant_speed,
    "hilly_terrain": scenario_hilly_terrain,
    "lane_change": scenario_lane_change,
    "rough_road": scenario_rough_road,
}


# --------------------------------------------------------------- simulation
def simulate(name, build_fn, seed):
    rng = np.random.default_rng(seed)
    t = np.arange(N) * DT
    sc = build_fn(t, rng)

    v_kph = np.clip(sc["v_kph"], 0.0, None)
    v_ms = v_kph / 3.6
    throttle = np.clip(sc["throttle"], 0.0, 100.0)
    brake = np.clip(sc["brake"], 0.0, 100.0)
    steer_deg = sc["steer"]

    # --- longitudinal / lateral body dynamics ---------------------------
    ax_g = first_difference(v_ms, 4, DT) / G
    ax_g += 0.01 * rng.standard_normal(N)

    steer_rad = np.radians(steer_deg)
    yaw_rate_rps = v_ms * np.tan(steer_rad) / WHEELBASE
    yaw_rate_dps = np.degrees(yaw_rate_rps)
    ay_g = v_ms * yaw_rate_rps / G
    ay_g += 0.005 * rng.standard_normal(N)

    roll_deg = ay_g * ROLL_GAIN
    pitch_deg = -ax_g * PITCH_GAIN
    roll_rate = first_difference(roll_deg, 3, DT)
    pitch_rate = first_difference(pitch_deg, 3, DT)

    # --- road input -> suspension / wheel response -----------------------
    roughness_mm = sc["roughness_mm"]
    road_mm = lowpass(rng.standard_normal(N), 6)
    road_mm *= roughness_mm / road_mm.std()
    if sc.get("washboard"):
        road_mm += 0.6 * roughness_mm * np.sin(2.0 * np.pi * 11.0 * t)

    road_mm_r = lowpass(rng.standard_normal(N), 6)
    road_mm_r *= roughness_mm / road_mm_r.std()
    if sc.get("washboard"):
        road_mm_r += 0.6 * roughness_mm * np.sin(2.0 * np.pi * 11.0 * t + 0.6)

    susp_fl = road_mm - 8.0 * ax_g + 5.0 * ay_g + 0.3 * rng.standard_normal(N)
    susp_fr = road_mm_r - 8.0 * ax_g - 5.0 * ay_g + 0.3 * rng.standard_normal(N)

    unsprung_fl = second_difference(road_mm / 1000.0, 3, DT)
    unsprung_fr = second_difference(road_mm_r / 1000.0, 3, DT)
    unsprung_fl += 0.15 * rng.standard_normal(N)
    unsprung_fr += 0.15 * rng.standard_normal(N)

    sprung_f = lowpass(0.35 * (unsprung_fl + unsprung_fr), 5)
    sprung_f += 0.03 * rng.standard_normal(N)

    az_g = 1.0 + 0.01 * sprung_f + 0.003 * rng.standard_normal(N)

    wheel_force_fl = (STATIC_LOAD - 750.0 * ax_g + 350.0 * ay_g
                       + 14.0 * susp_fl + 25.0 * rng.standard_normal(N))
    strain_lca = 230.0 + 0.15 * (wheel_force_fl - STATIC_LOAD) + 3.0 * rng.standard_normal(N)

    # --- GPS track --------------------------------------------------------
    heading_rad = np.cumsum(yaw_rate_rps) * DT
    dx = v_ms * np.cos(heading_rad) * DT
    dy = v_ms * np.sin(heading_rad) * DT
    x = np.cumsum(dx)
    y = np.cumsum(dy)
    lat = LAT0 + y / 111320.0
    lon = LON0 + x / (111320.0 * np.cos(np.radians(LAT0)))
    alt = ALT0 + sc.get("alt_extra", np.zeros(N)) + 0.05 * rng.standard_normal(N)

    cols = dict(
        Time=t, Throttle=throttle, Brake=brake, Steer=steer_deg, Speed=v_kph,
        Ax=ax_g, Ay=ay_g, Az=az_g, RollRate=roll_rate, PitchRate=pitch_rate,
        YawRate=yaw_rate_dps, GPS_Lat=lat, GPS_Lon=lon, GPS_Alt=alt,
        SprungAcc_F=sprung_f, UnsprungAcc_FL=unsprung_fl, UnsprungAcc_FR=unsprung_fr,
        SuspDisp_FL=susp_fl, SuspDisp_FR=susp_fr, WheelForce_FL=wheel_force_fl,
        Strain_LCA=strain_lca,
    )
    return cols, sc["comment"]


FMT = {
    "Time": "%.2f", "Throttle": "%.1f", "Brake": "%.2f", "Steer": "%.2f",
    "Speed": "%.3f", "Ax": "%.4f", "Ay": "%.4f", "Az": "%.4f",
    "RollRate": "%.3f", "PitchRate": "%.3f", "YawRate": "%.3f",
    "GPS_Lat": "%.7f", "GPS_Lon": "%.7f", "GPS_Alt": "%.2f",
    "SprungAcc_F": "%.3f", "UnsprungAcc_FL": "%.3f", "UnsprungAcc_FR": "%.3f",
    "SuspDisp_FL": "%.2f", "SuspDisp_FR": "%.2f", "WheelForce_FL": "%.1f",
    "Strain_LCA": "%.1f",
}


def write_csv(path, cols, comment):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", newline="\n") as f:
        f.write("# PlotIt example - automotive field test (synthetic, 100 Hz, 10 s)\n")
        f.write("# %s\n" % comment)
        f.write(", ".join(COLUMNS) + "\n")
        f.write(", ".join(UNITS) + "\n")
        for i in range(N):
            row = ", ".join(FMT[c] % cols[c][i] for c in COLUMNS)
            f.write(row + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", choices=list(SCENARIOS) + ["all"], default="all")
    ap.add_argument("out", nargs="?", help="output path (single-scenario runs only)")
    args = ap.parse_args()

    names = list(SCENARIOS) if args.scenario == "all" else [args.scenario]
    if args.out and len(names) != 1:
        ap.error("an output path can only be given with --scenario <name>")

    for i, name in enumerate(names):
        cols, comment = simulate(name, SCENARIOS[name], seed=20260815 + i)
        path = args.out or os.path.join(OUT_DIR, "automotive_%s.csv" % name)
        write_csv(path, cols, comment)
        print("wrote %s  (%d rows)" % (path, N))


if __name__ == "__main__":
    main()
