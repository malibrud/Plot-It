"""
Generate a short RPC3 (.tim) time history: a quick preview of the same
technique gen_perf_road_load.py uses at full durability-test scale, sized for
just looking at the file rather than stress-testing PlotIt.

10 channels x 16,384 points at 1 kHz (~16.4 s).

Physical story: a short run on the durability route -- accelerate up to
cruise, hold speed onto a rough patch of road, then brake down to a stop.
A distance-domain road profile (both wheel tracks, rear axle delayed by the
wheelbase) drives the suspension channels; longitudinal demand drives the
halfshaft torques; engine speed follows the gear/speed relationship.

Channel ranges are spread across several decades (mm / m/s^2 vs Nm vs rpm) so
PlotIt's range-based right-Y-axis assignment splits the traces onto two axes.
"""

import numpy as np
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _signal_helpers import moving_average, lowpass, first_difference, second_difference, to_rms

# ---------------------------------------------------------------- file layout
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "..", "examples", "rpc", "road_load_demo.tim")
OUT = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_OUT

PTS_PER_FRAME = 2048
PTS_PER_GROUP = 2048
FRAMES = 8
N = FRAMES * PTS_PER_FRAME          # 16,384
DT = 1.0e-3                         # 1 kHz
NCHAN = 10

PARAM_KEY_LEN = 32
PARAM_VAL_LEN = 96

rng = np.random.default_rng(20260815)
t0 = time.time()


def log(msg):
    print("[%6.2fs] %s" % (time.time() - t0, msg), flush=True)


def sample_at_distance(profile, dx, s):
    """Linear interpolation of a uniformly spaced distance-domain profile."""
    p = np.clip(s / dx, 0.0, profile.size - 1.0001)
    i = p.astype(np.int64)
    f = (p - i).astype(np.float32)
    return profile[i] * (1.0 - f) + profile[i + 1] * f


# ------------------------------------------------------- 1. speed / distance
log("building speed trace")
t = np.arange(N, dtype=np.float64) * DT
T = N * DT

# accelerate to 70 km/h, cruise, brake down to a stop -- one clean event
seg_t = np.array([0.0, 4.0, 9.5, 13.0, T])
target = np.array([0.0, 70.0, 70.0, 25.0, 5.0])
v_kph = np.interp(t, seg_t, target)
v_kph = lowpass(v_kph, 400)                 # driver/powertrain lag
v_kph += 0.10 * rng.standard_normal(N)
np.clip(v_kph, 0.0, None, out=v_kph)
v_ms = v_kph / 3.6

s = np.cumsum(v_ms) * DT                    # m travelled
s_max = float(s[-1])
log("route length %.1f m, duration %.1f s" % (s_max, T))

# ---------------------------------------------------- 2. road profile (spatial)
log("synthesising road profile")
DX = 0.05                                   # m spatial resolution
WHEELBASE = 2.85                            # m
nx = int((s_max + 4.0 * WHEELBASE) / DX) + 4

white = rng.standard_normal(nx)
spec = np.fft.rfft(white)
n_sp = np.fft.rfftfreq(nx, DX)              # cycles / m
n_sp[0] = n_sp[1]
shape = (n_sp / 0.1) ** -1.0                # amplitude ~ n^-1  => PSD ~ n^-2
shape[n_sp < 1.0 / 40.0] = 0.0
shape[n_sp > 1.0] = 0.0
common = np.fft.irfft(spec * shape, nx)
common *= 0.010 / common.std()              # ~10 mm RMS road (baseline)

white = rng.standard_normal(nx)
indep_l = np.fft.irfft(np.fft.rfft(white) * shape, nx)
indep_l *= 0.005 / indep_l.std()
white = rng.standard_normal(nx)
indep_r = np.fft.irfft(np.fft.rfft(white) * shape, nx)
indep_r *= 0.005 / indep_r.std()

# a rough patch under the cruise section (~9.5-13s of the clip), smoothed edges
x = np.arange(nx) * DX
x_rough_lo, x_rough_hi = float(np.interp(9.5, t, s)), float(np.interp(13.0, t, s))
rough_gain = 1.0 + 1.4 * ((x >= x_rough_lo) & (x <= x_rough_hi))
rough_gain = lowpass(rough_gain, int(2.0 / DX))             # ~2 m transition
road_l = ((common + indep_l) * rough_gain).astype(np.float32)   # m
road_r = ((common + indep_r) * rough_gain).astype(np.float32)   # m
del white, spec, common, indep_l, indep_r, shape, n_sp, rough_gain, x

# ------------------------------------------------------------- 3. channel defs
CHANNELS = [
    ("LF Wheel Displacement",       "mm"),
    ("RF Wheel Displacement",       "mm"),
    ("LR Wheel Displacement",       "mm"),
    ("Body Vertical Acceleration",  "m/s^2"),
    ("LF Spindle Vert Accel",       "m/s^2"),
    ("RR Spindle Vert Accel",       "m/s^2"),
    ("LH Halfshaft Torque",         "Nm"),
    ("RH Halfshaft Torque",         "Nm"),
    ("Engine Speed",                "rpm"),
    ("Vehicle Speed",               "km/h"),
]
assert len(CHANNELS) == NCHAN

channel_data = [None] * NCHAN
limits = []


def emit(idx, x):
    x = np.asarray(x, dtype=np.float32)
    assert x.size == N
    limits.append((float(x.min()), float(x.max())))
    channel_data[idx] = x
    lo, hi = limits[-1]
    log("  ch%-2d %-28s %9.2f .. %9.2f  rms %8.2f  %s"
        % (idx + 1, CHANNELS[idx][0], lo, hi, float(x.std()), CHANNELS[idx][1]))


log("generating channels")

# --- suspension displacement (mm at the wheel), bump stops at +/- 60 mm -------
# Gain is set from the baseline (non-rough) section's RMS, not the whole record,
# so the rough patch reads as a clear step up in activity rather than pinning
# the signal against the bump stops for its whole duration.
BUMP = 60.0
DISP_RMS = 9.0
baseline_mask = (t < 9.5) | (t > 13.0)
disp_lf = sample_at_distance(road_l, DX, s) * 1000.0
gain = DISP_RMS / disp_lf[baseline_mask].std()
disp_lf *= gain
disp_rf = sample_at_distance(road_r, DX, s) * 1000.0 * gain
disp_lr = sample_at_distance(road_l, DX, np.maximum(s - WHEELBASE, 0.0)) * 1000.0 \
    * gain * 0.92

body_mm = lowpass(disp_lf + disp_rf, 60) * 0.5
for d in (disp_lf, disp_rf, disp_lr):
    d += body_mm.astype(np.float32) * 0.30

emit(0, np.clip(disp_lf, -BUMP, BUMP))
emit(1, np.clip(disp_rf, -BUMP, BUMP))
emit(2, np.clip(disp_lr, -BUMP, BUMP))
del disp_lr

# --- body vertical acceleration (m/s^2), sprung mass, +/-12 m/s^2 sensor -----
acc_body = to_rms(second_difference(lowpass(body_mm, 15) / 1000.0, 8, DT), 1.2)
acc_body += 0.05 * rng.standard_normal(N)
emit(3, np.clip(acc_body, -12.0, 12.0))
del acc_body, body_mm

# --- spindle (unsprung) vertical acceleration, wheel-hop rich, +/-60 m/s^2 ---
SPINDLE_RMS = 7.0
SPINDLE_LIMIT = 100.0
tread = to_rms(lowpass(rng.standard_normal(N), 3), 1.0) * (v_ms / 18.0)

wheel_l_m = lowpass(disp_lf, 5) / 1000.0
acc_lf = to_rms(second_difference(wheel_l_m, 3, DT), SPINDLE_RMS)
acc_lf += 0.35 * np.sin(2.0 * np.pi * 12.4 * t) * lowpass(np.abs(acc_lf), 200)
acc_lf += 2.5 * tread + 0.20 * rng.standard_normal(N)
emit(4, np.clip(acc_lf, -SPINDLE_LIMIT, SPINDLE_LIMIT))
del acc_lf, wheel_l_m, disp_lf

wheel_r_m = lowpass(sample_at_distance(road_r, DX, np.maximum(s - WHEELBASE, 0.0))
                    * 1000.0 * gain * 0.92, 5) / 1000.0
acc_rr = to_rms(second_difference(wheel_r_m, 3, DT), SPINDLE_RMS * 0.85)
acc_rr += 0.35 * np.sin(2.0 * np.pi * 11.6 * t + 0.7) * lowpass(np.abs(acc_rr), 200)
acc_rr += 2.2 * tread + 0.20 * rng.standard_normal(N)
emit(5, np.clip(acc_rr, -SPINDLE_LIMIT, SPINDLE_LIMIT))
del tread
del acc_rr, wheel_r_m, disp_rf, road_l, road_r

# --- driveline ---------------------------------------------------------------
a_long = first_difference(lowpass(v_ms, 100), 50, DT)      # m/s^2
np.clip(a_long, -6.0, 3.2, out=a_long)

MASS = 1750.0
R_WHEEL = 0.34
C_RR = 0.011
C_AERO = 0.42
drag = C_RR * MASS * 9.81 + C_AERO * v_ms ** 2
axle_torque = (MASS * a_long + drag) * R_WHEEL
np.clip(axle_torque, -350.0, None, out=axle_torque)
axle_torque[v_ms < 0.5] = 0.0
half = 0.5 * axle_torque
ring = np.clip(to_rms(np.abs(first_difference(a_long, 20, DT)), 90.0), 0.0, 320.0)
osc = ring * np.sin(2.0 * np.pi * 9.2 * t)
emit(6, np.clip(half + osc + 12.0 * rng.standard_normal(N), -1600.0, 1600.0))
emit(7, np.clip(half * 0.96 - osc * 0.85 + 12.0 * rng.standard_normal(N),
                -1600.0, 1600.0))
del axle_torque, half, osc, ring, drag

# --- engine speed ------------------------------------------------------------
GEARS = np.array([3.55, 2.05, 1.35, 1.00, 0.78, 0.63])
UPSHIFT_KPH = np.array([25.0, 45.0, 70.0, 95.0, 120.0])
FINAL = 3.90
gear = np.searchsorted(UPSHIFT_KPH, v_kph)
ratio = (GEARS[gear] * FINAL).astype(np.float64)
rpm = v_ms / (2.0 * np.pi * R_WHEEL) * 60.0 * ratio
rpm = lowpass(rpm, 40)
rpm = np.maximum(rpm, 720.0)
rpm += 22.0 * a_long + 6.0 * rng.standard_normal(N)
emit(8, np.clip(rpm, 640.0, 5600.0))
del rpm, ratio, gear, a_long

# --- vehicle speed -----------------------------------------------------------
emit(9, np.clip(v_kph + 0.05 * rng.standard_normal(N), 0.0, None))
del v_kph, v_ms, s, t

# --------------------------------------------------------------- 4. RPC header
log("writing header")


def param(key, val):
    k = key.encode("ascii")
    v = str(val).encode("ascii")
    assert len(k) < PARAM_KEY_LEN and len(v) < PARAM_VAL_LEN, key
    return k.ljust(PARAM_KEY_LEN, b"\0") + v.ljust(PARAM_VAL_LEN, b"\0")


params = [
    ("FORMAT", "BINARY_IEEE_LITTLE_END"),
    ("NUM_HEADER_BLOCKS", 0),                 # patched below
    ("NUM_PARAMS", 0),                        # patched below
    ("FILE_TYPE", "TIME_HISTORY"),
    ("DATA_TYPE", "FLOATING_POINT"),
    ("TIME_TYPE", "RESPONSE"),
    ("DELTA_T", "%.6E" % DT),
    ("DESCRIPTION", "Road load demo - accel, cruise, rough patch, brake"),
    ("CHANNELS", NCHAN),
    ("COMPUTED_CHANNELS", 0),
    ("PTS_PER_FRAME", PTS_PER_FRAME),
    ("PTS_PER_GROUP", PTS_PER_GROUP),
    ("BYPASS_FILTER", 0),
    ("HALF_FRAMES", 0),
    ("REPEATS", 0),
    ("FRAMES", FRAMES),
    ("PARTITIONS", 1),
    ("PART.CHAN_1", 1),
    ("PART.NCHAN_1", NCHAN),
    ("DATE", "15-Aug-2026  09:00:00"),
    ("OPERATION", ""),
    ("AVERAGES", 0),
]
for i, (desc, unit) in enumerate(CHANNELS):
    c = "CHAN_%d" % (i + 1)
    lo, hi = limits[i]
    params += [
        ("DESC." + c, desc),
        ("UNITS." + c, unit),
        ("MAP." + c, desc),
        ("SCALE." + c, "1.000000E+000"),
        ("UPPER_LIMIT." + c, "%.6E" % hi),
        ("LOWER_LIMIT." + c, "%.6E" % lo),
    ]

nparams = len(params)
nblocks = (nparams * (PARAM_KEY_LEN + PARAM_VAL_LEN) + 511) // 512
params[1] = ("NUM_HEADER_BLOCKS", nblocks)
params[2] = ("NUM_PARAMS", nparams)

header = b"".join(param(k, v) for k, v in params)
header = header.ljust(nblocks * 512, b"\0")

# ------------------------------------------------- 5. interleave and write data
log("interleaving %d frames x %d channels" % (FRAMES, NCHAN))
block = np.empty((FRAMES, NCHAN, PTS_PER_FRAME), dtype=np.float32)
for ic in range(NCHAN):
    block[:, ic, :] = channel_data[ic].reshape(FRAMES, PTS_PER_FRAME)

os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
with open(OUT, "wb") as f:
    f.write(header)
    block.tofile(f)

log("wrote %s  (%.2f MB)" % (OUT, os.path.getsize(OUT) / 1e6))
