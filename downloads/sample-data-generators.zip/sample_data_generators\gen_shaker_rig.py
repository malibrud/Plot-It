"""
Generate a synthetic fstrm (Moog Stream) file for PlotIt: a 4-post durability
shaker rig replaying a rough-road displacement profile through the four
actuators, with the resulting seat/floor/dash accelerations and actuator
load-cell force.

8 channels x 7168 points at 512 Hz (14.0 s).

Story: a quiet baseline (rig idling on a smooth profile), a rough-road burst
through the middle of the clip, then settling back down -- something to zoom
into for a demo.
"""

import numpy as np
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _signal_helpers import lowpass, second_difference, first_difference, to_rms

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "..", "examples", "fstrm", "shaker_rig_rough_road.fstrm")
OUT = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_OUT

DT = 1.0 / 512.0            # 512 Hz
N = 7168                    # 14.0 s
NCHAN = 8

CHANNELS = [
    ("LF Actuator Displacement", "mm"),
    ("RF Actuator Displacement", "mm"),
    ("LR Actuator Displacement", "mm"),
    ("RR Actuator Displacement", "mm"),
    ("Seat Rail Vertical Accel", "g"),
    ("Floor Vertical Accel", "g"),
    ("Dash Panel Vertical Accel", "g"),
    ("Actuator Load Cell Force", "N"),
]

rng = np.random.default_rng(20260815)
t = np.arange(N, dtype=np.float64) * DT


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


# Quiet baseline, rough patch from t=4s to t=10s, settle back down.
env = 0.15 + 0.85 * (sigmoid((t - 4.0) / 0.5) - sigmoid((t - 10.0) / 0.5))

# --- four actuator posts: independent filtered-noise displacement, same envelope
POST_GAIN = [1.0, 0.9, 0.85, 0.78]     # LF, RF, LR, RR relative amplitude
disp = []
for gain in POST_GAIN:
    raw = lowpass(rng.standard_normal(N), 8)
    raw /= raw.std()
    disp.append(raw * env * 20.0 * gain)          # mm
disp_lf, disp_rf, disp_lr, disp_rr = disp

# --- structural response: floor tracks the input most directly, seat and dash
# are progressively more filtered/isolated, each with its own resonant ring
# that grows with the rough-patch envelope. A large stride on the second
# difference keeps the derivative from amplifying content far above what a
# structure actually transmits; to_rms then sets the overall level (the
# baseline/burst shape survives since both steps are linear).
front_accel = second_difference((0.5 * disp_lf + 0.5 * disp_rf) / 1000.0, 10, DT)   # m/s^2
rear_accel = second_difference((0.5 * disp_lr + 0.5 * disp_rr) / 1000.0, 10, DT)

floor_g = to_rms(0.5 * front_accel + 0.5 * rear_accel, 3.2) / 9.81   # ~0.33 g overall RMS
floor_g += 0.010 * rng.standard_normal(N)

ring_amp = env * lowpass(np.abs(rng.standard_normal(N)), 50)
seat_g = lowpass(floor_g, 5) * 0.7 + 0.10 * ring_amp * np.sin(2.0 * np.pi * 17.0 * t)
seat_g += 0.020 * rng.standard_normal(N)

dash_g = lowpass(floor_g, 10) * 0.4 + 0.05 * ring_amp * np.sin(2.0 * np.pi * 22.0 * t + 0.8)
dash_g += 0.015 * rng.standard_normal(N)

# --- actuator load-cell force: preload plus a term driven by combined post velocity
combined_vel = first_difference((disp_lf + disp_rf + disp_lr + disp_rr) / 4.0, 10, DT)  # mm/s
force_n = 1500.0 + to_rms(combined_vel, 320.0) + 60.0 * rng.standard_normal(N)
force_n = np.clip(force_n, 200.0, 3800.0)

DATA = [disp_lf, disp_rf, disp_lr, disp_rr, seat_g, floor_g, dash_g, force_n]
assert len(DATA) == NCHAN

for (desc, unit), x in zip(CHANNELS, DATA):
    print("  %-28s %9.2f .. %9.2f  rms %8.2f  %s"
          % (desc, float(x.min()), float(x.max()), float(x.std()), unit))

# ------------------------------------------------------------------- write it
os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
with open(OUT, "wb") as f:
    f.write(b"#fstrm-1.0\n")
    f.write(b"[Header]\n")
    f.write(b"Format=Binary\n")
    f.write(("TimeInterval=%.10f\n" % DT).encode("ascii"))
    for i, (desc, unit) in enumerate(CHANNELS):
        f.write(("Channel %d=%s;Unit=%s;Format=Float;\n" % (i, desc, unit)).encode("ascii"))
    f.write(b"[Data]\n")

    block = np.empty((N, NCHAN), dtype=np.float32)
    for c, x in enumerate(DATA):
        block[:, c] = x
    block.tofile(f)

print("wrote %s  (%.2f MB)" % (OUT, os.path.getsize(OUT) / 1e6))
