"""
Generate a synthetic .plt/.hdr pair for PlotIt: a hybrid/electric powertrain
simulation trace (the kind of output a vehicle-dynamics model like
SimCreator would produce), not recorded sensor data.

10 channels x 1600 points at 100 Hz (16.0 s).

Story: standing start, wide-open-throttle launch to ~110 km/h, a short
cruise, then a regenerative-braking coast-down to a stop.
"""

import numpy as np
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _signal_helpers import lowpass, first_difference

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "..", "examples", "plt", "hev_powertrain_demo.plt")
OUT_PLT = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_OUT
OUT_HDR = OUT_PLT[:-4] + ".hdr" if OUT_PLT.endswith(".plt") else OUT_PLT + ".hdr"

DT = 0.01           # 100 Hz
N = 1600             # 16.0 s

CHANNELS = [
    ("Accelerator Pedal", "%"),
    ("Brake Pedal", "%"),
    ("Vehicle Speed", "km/h"),
    ("Motor Torque", "Nm"),
    ("Motor Current", "Amperes"),
    ("Battery Pack Voltage", "Volts"),
    ("Battery SOC", "%"),
    ("Regen Power", "kW"),
    ("Motor Speed", "rpm"),
]

rng = np.random.default_rng(20260815)
t = np.arange(N, dtype=np.float64) * DT


def smooth_interp(waypoints, w):
    wp_t = np.array([p[0] for p in waypoints], dtype=np.float64)
    wp_v = np.array([p[1] for p in waypoints], dtype=np.float64)
    return lowpass(np.interp(t, wp_t, wp_v), w)


# --- driver inputs and speed --------------------------------------------
accel_pedal = smooth_interp([(0, 0), (0.8, 100), (6.5, 100), (7.5, 25),
                              (9.8, 22), (10.0, 0), (16, 0)], w=15)
brake_pedal = smooth_interp([(0, 0), (10.0, 0), (10.3, 0), (11.0, 62),
                              (14.5, 62), (15.2, 0), (16, 0)], w=15)

v_kph = smooth_interp([(0, 0), (2, 35), (3.5, 62), (5, 85), (7, 108),
                        (10, 110), (11, 108), (13.5, 45), (15.2, 0), (16, 0)], w=20)
v_kph = np.clip(v_kph, 0.0, None)
v_ms = v_kph / 3.6

# --- driveline: derive torque demand from the speed trace, same technique
# gen_perf_road_load.py uses for halfshaft torque ------------------------
a_long = first_difference(lowpass(v_ms, 20), 8, DT)        # m/s^2
MASS = 1800.0            # kg
R_WHEEL = 0.33            # m
RATIO = 9.0               # single-speed reduction gear
C_RR = 0.010
C_AERO = 0.35
drag = C_RR * MASS * 9.81 + C_AERO * v_ms ** 2
wheel_torque = (MASS * a_long + drag) * R_WHEEL
motor_torque = np.clip(wheel_torque / RATIO, -340.0, 340.0)
motor_torque += 3.0 * rng.standard_normal(N)

# --- electrical side ------------------------------------------------------
K_I = 1.18                              # A / Nm
motor_current = motor_torque * K_I + 6.0 * rng.standard_normal(N)

V_NOMINAL = 360.0
R_INT = 0.045                            # ohm, simple pack internal resistance
battery_voltage = V_NOMINAL - R_INT * motor_current + 0.6 * rng.standard_normal(N)

power_w = motor_current * battery_voltage
CAPACITY_WH = 60000.0
soc = 72.0 - np.cumsum(power_w) * DT / (CAPACITY_WH * 3600.0) * 100.0
soc += 0.02 * rng.standard_normal(N)

regen_kw = np.clip(-motor_current * battery_voltage / 1000.0, 0.0, None)

motor_speed_rpm = v_ms / (2.0 * np.pi * R_WHEEL) * 60.0 * RATIO

COLUMNS = [
    accel_pedal, brake_pedal, v_kph, motor_torque, motor_current,
    battery_voltage, soc, regen_kw, motor_speed_rpm,
]
assert len(COLUMNS) == len(CHANNELS)

for (desc, unit), x in zip(CHANNELS, COLUMNS):
    print("  %-22s %10.2f .. %10.2f  %s" % (desc, float(x.min()), float(x.max()), unit))

# ------------------------------------------------------------------ write it
os.makedirs(os.path.dirname(os.path.abspath(OUT_PLT)), exist_ok=True)

with open(OUT_HDR, "w", newline="\n") as f:
    f.write("1: Time (seconds)\n")
    for i, (desc, unit) in enumerate(CHANNELS):
        f.write("%d: %s (%s)\n" % (i + 2, desc, unit))

FMT = ["%.2f", "%.1f", "%.1f", "%.3f", "%.1f", "%.2f", "%.2f", "%.3f", "%.3f", "%.1f"]
with open(OUT_PLT, "w", newline="\n") as f:
    for i in range(N):
        row = [t[i]] + [c[i] for c in COLUMNS]
        f.write(" ".join(fmt % v for fmt, v in zip(FMT, row)) + "\n")

print("wrote %s and %s" % (OUT_PLT, OUT_HDR))
