# PlotIt sample-data generators

Python scripts that generate synthetic time-history files in every format
PlotIt reads: RPC3 (`.tim`), CSV, fstrm, and PLT/`.hdr`. All data is entirely
synthetic -- no proprietary or recorded data of any kind.

## Requirements

- Python 3.9+
- [NumPy](https://numpy.org/) -- `pip install numpy`

## Running

Each script can be run directly and takes no required arguments -- it writes
its output next to this directory, in the matching `examples/<format>/`
subfolder of the repo:

```bash
python gen_automotive_csv.py
python gen_shaker_rig.py
python gen_hev_powertrain.py
python gen_road_load_demo.py
python gen_perf_road_load.py
```

Every script accepts an output path as its first command-line argument if you
want the file written somewhere else instead:

```bash
python gen_shaker_rig.py C:\data\my_shaker_test.fstrm
```

## Scripts

| Script | Format | Length | What it generates |
|---|---|---|---|
| `gen_automotive_csv.py` | `.csv` | 10 s @ 100 Hz | Six automotive field-test maneuvers (launch, braking, constant-speed cruise, hilly terrain, double lane change, rough road), sharing one 21-channel schema (throttle/brake/steer inputs, body accelerations and rates, GPS, suspension and wheel-force response). Pass `--scenario NAME` to write just one, or `--scenario all` (default) for all six. |
| `gen_shaker_rig.py` | `.fstrm` | 14 s @ 512 Hz | A 4-post durability shaker rig replaying a rough-road displacement profile through the four actuators, with the resulting seat/floor/dash accelerations and actuator load cell force. Quiet baseline, a rough-road burst in the middle, settles back down. |
| `gen_hev_powertrain.py` | `.plt` + `.hdr` | 16 s @ 100 Hz | A hybrid-electric powertrain simulation: standing start, wide-open-throttle launch to ~110 km/h, a short cruise, then a regenerative-braking coast-down to a stop. |
| `gen_road_load_demo.py` | `.tim` (RPC3) | ~15 s @ 1 kHz | A short durability road-load snippet -- the same distance-domain road-profile technique as `gen_perf_road_load.py`, sized for quickly previewing the format instead of stress-testing PlotIt. |
| `gen_perf_road_load.py` | `.tim` (RPC3) | ~4 h 10 min @ 1 kHz | A large (~600 MB, 15M-point) durability road-load file for performance testing PlotIt at scale, not for a quick look. Set `RPC_FRAMES` in the environment to change its length. |

## Shared code

`_signal_helpers.py` holds a handful of small NumPy utilities (moving
average, low-pass, first/second difference, RMS scaling) used by more than
one script above. It isn't meant to be run on its own.
