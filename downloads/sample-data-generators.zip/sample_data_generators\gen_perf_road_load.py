"""
Generate a large RPC3 (.tim) time history for PlotIt performance testing.

10 channels x 15,001,600 points at 1 kHz  (~4 h 10 min of durability road-load data)
FLOATING_POINT (float32) -> ~600 MB of sample data.

Physical story: a vehicle running a durability / road-load-data route.  A drive
cycle (speed profile) drives the distance travelled; a distance-domain ISO-8608
style road profile (both wheel tracks, rear axle delayed by the wheelbase) drives
the suspension channels; longitudinal demand drives the halfshaft torques and the
engine speed follows the gear/speed relationship.

Channel ranges are deliberately spread across several decades (mm / m/s^2 vs Nm vs
rpm) so PlotIt's range-based right-Y-axis assignment splits the traces onto two axes.

Not sized for a quick preview -- see gen_road_load_demo.py for a ~15 s sample of
the same technique. Set RPC_FRAMES in the environment to change the length here.
"""

import numpy as np
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _signal_helpers import moving_average, lowpass, first_difference, second_difference, to_rms

# ---------------------------------------------------------------- file layout
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "..", "examples", "rpc", "durability_road_load_15M.tim")
OUT = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_OUT
TMPDIR = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.abspath(OUT))

PTS_PER_FRAME = 2048
PTS_PER_GROUP = 2048
FRAMES = int(os.environ.get("RPC_FRAMES", 7325))
N = FRAMES * PTS_PER_FRAME          # 15,001,600
DT = 1.0e-3                         # 1 kHz
NCHAN = 10

PARAM_KEY_LEN = 32
PARAM_VAL_LEN = 96

rng = np.random.default_rng(20260725)
t0 = time.time()


def log(msg):
    print("[%7.1fs] %s" % (time.time() - t0, msg), flush=True)


def sample_at_distance(profile, dx, s):
    """Linear interpolation of a uniformly spaced distance-domain profile."""
    p = np.clip(s / dx, 0.0, profile.size - 1.0001)
    i = p.astype(np.int64)
    f = (p - i).astype(np.float32)
    return profile[i] * (1.0 - f) + profile[i + 1] * f


# ------------------------------------------------------- 1. drive cycle (speed)
log("building drive cycle")
SEG = 5.0                                   # s per drive-cycle break point
nseg = int(N * DT / SEG) + 2
seg_t = np.arange(nseg) * SEG

# Route: repeating urban / rural / highway blocks, each ~10 min.
BLOCK = 600.0
phase = (seg_t % (3.0 * BLOCK)) / BLOCK
target = np.empty(nseg)
target[phase < 1.0] = 35.0                  # urban
target[(phase >= 1.0) & (phase < 2.0)] = 75.0   # rural
target[phase >= 2.0] = 115.0                # highway
# traffic / driver variation on the block target
target *= 1.0 + 0.22 * np.sin(2.0 * np.pi * seg_t / 71.0) \
             + 0.13 * np.sin(2.0 * np.pi * seg_t / 23.0 + 1.1) \
             + 0.10 * rng.standard_normal(nseg)
# stops in the urban blocks
stop = (phase < 1.0) & (np.sin(2.0 * np.pi * seg_t / 47.0) > 0.72)
target[stop] = 0.0
target = np.clip(target, 0.0, 130.0)

t = np.arange(N, dtype=np.float64) * DT
v_kph = np.interp(t, seg_t, target)         # piecewise-linear -> constant-accel ramps
v_kph = lowpass(v_kph, 1500)                # driver/powertrain lag, ~1.5 s
v_kph += 0.35 * np.sin(2.0 * np.pi * 0.21 * t) + 0.12 * rng.standard_normal(N)
np.clip(v_kph, 0.0, None, out=v_kph)
v_ms = v_kph / 3.6

log("integrating distance")
s = np.cumsum(v_ms) * DT                    # m travelled
s_max = float(s[-1])
log("route length %.1f km, duration %.2f h" % (s_max / 1000.0, N * DT / 3600.0))

# ---------------------------------------------------- 2. road profile (spatial)
log("synthesising road profile")
DX = 0.05                                   # m spatial resolution
WHEELBASE = 2.85                            # m
nx = int((s_max + 4.0 * WHEELBASE) / DX) + 4

# ISO 8608-like displacement PSD  Gd(n) ~ n^-2  (class C/D unpaved-ish sections)
white = rng.standard_normal(nx)
spec = np.fft.rfft(white)
n_sp = np.fft.rfftfreq(nx, DX)              # cycles / m
n_sp[0] = n_sp[1]
shape = (n_sp / 0.1) ** -1.0                # amplitude ~ n^-1  => PSD ~ n^-2
# Keep only what the suspension actually sees: hills (> 40 m) are elevation, not
# road input, and content finer than ~1 m is left to the tyre.  The 1 m floor also
# keeps the spatial->time interpolation smooth (20 grid points per wavelength), so
# differentiating for acceleration doesn't amplify interpolation kinks.
shape[n_sp < 1.0 / 40.0] = 0.0
shape[n_sp > 1.0] = 0.0
common = np.fft.irfft(spec * shape, nx)
common *= 0.012 / common.std()              # ~12 mm RMS road

white = rng.standard_normal(nx)
indep_l = np.fft.irfft(np.fft.rfft(white) * shape, nx)
indep_l *= 0.006 / indep_l.std()
white = rng.standard_normal(nx)
indep_r = np.fft.irfft(np.fft.rfft(white) * shape, nx)
indep_r *= 0.006 / indep_r.std()

# rougher sections (broken pavement / Belgian block) every few km
km = np.arange(nx) * DX / 1000.0
rough_gain = 1.0 + 1.2 * (np.sin(2.0 * np.pi * km / 7.3) > 0.55)
road_l = ((common + indep_l) * rough_gain).astype(np.float32)   # m
road_r = ((common + indep_r) * rough_gain).astype(np.float32)   # m
del white, spec, common, indep_l, indep_r, shape, n_sp, rough_gain, km

# ------------------------------------------------------------- 3. channel defs
CHANNELS = [
    ("LF Wheel Displacement",       "mm"),
    ("RF Wheel Displacement",       "mm"),
    ("LR Wheel Displacement",       "mm"),
    ("Body Vertical Acceleration",  "m/s^2"),
    ("LF Spindle Vert Accel",       "m/s^2"),
    ("RR Spindle Vert Accel",       "m/s^2"),
    ("LH Halfshaft Torque",         "Nm"),
    ("RH Halfshaft Torque",         "Nm"),
    ("Engine Speed",                "rpm"),
    ("Vehicle Speed",               "km/h"),
]
assert len(CHANNELS) == NCHAN

tmp_paths = [os.path.join(TMPDIR, "chan_%02d.f32" % i) for i in range(NCHAN)]
limits = []


def emit(idx, x):
    x = np.asarray(x, dtype=np.float32)
    assert x.size == N
    limits.append((float(x.min()), float(x.max())))
    x.tofile(tmp_paths[idx])
    lo, hi = limits[-1]
    at_limit = float(np.count_nonzero((x <= lo) | (x >= hi))) / x.size
    log("  ch%-2d %-28s %9.2f .. %9.2f  rms %8.2f  at-limit %.4f%%  %s"
        % (idx + 1, CHANNELS[idx][0], lo, hi, float(x.std()),
           100.0 * at_limit, CHANNELS[idx][1]))


log("generating channels")

# --- suspension displacement (mm at the wheel), bump stops at +/- 60 mm -------
# Levels are set from the target RMS of the front-left channel; the other corners
# keep their relative amplitudes so the corner-to-corner comparison stays honest.
BUMP = 60.0
DISP_RMS = 12.0                                            # mm, durability route
disp_lf = sample_at_distance(road_l, DX, s) * 1000.0
gain = DISP_RMS / disp_lf.std()
disp_lf *= gain
disp_rf = sample_at_distance(road_r, DX, s) * 1000.0 * gain
disp_lr = sample_at_distance(road_l, DX, np.maximum(s - WHEELBASE, 0.0)) * 1000.0 \
    * gain * 0.92                                          # softer rear rate

# body heave rides the long-wavelength road content (~1.3 Hz sprung mode)
body_mm = lowpass(disp_lf + disp_rf, 320) * 0.5
for d in (disp_lf, disp_rf, disp_lr):
    d += body_mm.astype(np.float32) * 0.30

emit(0, np.clip(disp_lf, -BUMP, BUMP))
emit(1, np.clip(disp_rf, -BUMP, BUMP))
emit(2, np.clip(disp_lr, -BUMP, BUMP))
del disp_lr

# --- body vertical acceleration (m/s^2), sprung mass, +/-12 m/s^2 sensor -----
acc_body = to_rms(second_difference(lowpass(body_mm, 60) / 1000.0, 15, DT), 1.3)
acc_body += 0.05 * rng.standard_normal(N)                  # sensor noise
emit(3, np.clip(acc_body, -12.0, 12.0))
del acc_body, body_mm

# --- spindle (unsprung) vertical acceleration, wheel-hop rich, +/-60 m/s^2 ---
SPINDLE_RMS = 8.0
SPINDLE_LIMIT = 100.0                                      # +/-10 g accelerometer
# tyre-level broadband input (tread / coarse aggregate), grows with road speed
tread = to_rms(lowpass(rng.standard_normal(N), 3), 1.0) * (v_ms / 18.0)

wheel_l_m = lowpass(disp_lf, 8) / 1000.0
acc_lf = to_rms(second_difference(wheel_l_m, 3, DT), SPINDLE_RMS)
acc_lf += 0.35 * np.sin(2.0 * np.pi * 12.4 * t) * lowpass(np.abs(acc_lf), 400)
acc_lf += 2.5 * tread + 0.20 * rng.standard_normal(N)
emit(4, np.clip(acc_lf, -SPINDLE_LIMIT, SPINDLE_LIMIT))
del acc_lf, wheel_l_m, disp_lf

wheel_r_m = lowpass(sample_at_distance(road_r, DX, np.maximum(s - WHEELBASE, 0.0))
                    * 1000.0 * gain * 0.92, 8) / 1000.0
acc_rr = to_rms(second_difference(wheel_r_m, 3, DT), SPINDLE_RMS * 0.85)
acc_rr += 0.35 * np.sin(2.0 * np.pi * 11.6 * t + 0.7) * lowpass(np.abs(acc_rr), 400)
acc_rr += 2.2 * tread + 0.20 * rng.standard_normal(N)
emit(5, np.clip(acc_rr, -SPINDLE_LIMIT, SPINDLE_LIMIT))
del tread
del acc_rr, wheel_r_m, disp_rf, road_l, road_r

# --- driveline ---------------------------------------------------------------
# longitudinal acceleration demand from the speed trace
a_long = first_difference(lowpass(v_ms, 300), 150, DT)     # m/s^2
# Cap the tractive demand at what the powertrain can actually deliver; harder
# decelerations are handled by the brakes, not the driveline.
np.clip(a_long, -6.0, 3.2, out=a_long)

MASS = 1750.0          # kg
R_WHEEL = 0.34         # m
C_RR = 0.011           # rolling resistance coeff
C_AERO = 0.42          # 0.5*rho*Cd*A  [N/(m/s)^2]
drag = C_RR * MASS * 9.81 + C_AERO * v_ms ** 2
axle_torque = (MASS * a_long + drag) * R_WHEEL              # Nm, both halfshafts
# Decel beyond engine braking goes into the friction brakes, not the halfshafts.
np.clip(axle_torque, -350.0, None, out=axle_torque)
axle_torque[v_ms < 0.5] = 0.0
half = 0.5 * axle_torque
# driveline torsional mode ~9 Hz, excited by demand changes and shift events
ring = np.clip(to_rms(np.abs(first_difference(a_long, 60, DT)), 90.0), 0.0, 320.0)
osc = ring * np.sin(2.0 * np.pi * 9.2 * t)
emit(6, np.clip(half + osc + 12.0 * rng.standard_normal(N), -1600.0, 1600.0))
emit(7, np.clip(half * 0.96 - osc * 0.85 + 12.0 * rng.standard_normal(N),
                -1600.0, 1600.0))
del axle_torque, half, osc, ring, drag

# --- engine speed ------------------------------------------------------------
GEARS = np.array([3.55, 2.05, 1.35, 1.00, 0.78, 0.63])
UPSHIFT_KPH = np.array([25.0, 45.0, 70.0, 95.0, 120.0])    # 1->2 ... 5->6
FINAL = 3.90
gear = np.searchsorted(UPSHIFT_KPH, v_kph)                 # 0..5
ratio = (GEARS[gear] * FINAL).astype(np.float64)
rpm = v_ms / (2.0 * np.pi * R_WHEEL) * 60.0 * ratio
rpm = lowpass(rpm, 120)                                    # clutch/torque-converter slip
rpm = np.maximum(rpm, 720.0)                               # idle
rpm += 22.0 * a_long + 6.0 * rng.standard_normal(N)        # load ripple
emit(8, np.clip(rpm, 640.0, 5600.0))
del rpm, ratio, gear, a_long

# --- vehicle speed -----------------------------------------------------------
emit(9, np.clip(v_kph + 0.05 * rng.standard_normal(N), 0.0, None))
del v_kph, v_ms, s, t

# --------------------------------------------------------------- 4. RPC header
log("writing header")


def param(key, val):
    k = key.encode("ascii")
    v = str(val).encode("ascii")
    assert len(k) < PARAM_KEY_LEN and len(v) < PARAM_VAL_LEN, key
    return k.ljust(PARAM_KEY_LEN, b"\0") + v.ljust(PARAM_VAL_LEN, b"\0")


params = [
    ("FORMAT", "BINARY_IEEE_LITTLE_END"),
    ("NUM_HEADER_BLOCKS", 0),                 # patched below
    ("NUM_PARAMS", 0),                        # patched below
    ("FILE_TYPE", "TIME_HISTORY"),
    ("DATA_TYPE", "FLOATING_POINT"),
    ("TIME_TYPE", "RESPONSE"),
    ("DELTA_T", "%.6E" % DT),
    ("DESCRIPTION", "Durability road load - urban/rural/highway loop"),
    ("CHANNELS", NCHAN),
    ("COMPUTED_CHANNELS", 0),
    ("PTS_PER_FRAME", PTS_PER_FRAME),
    ("PTS_PER_GROUP", PTS_PER_GROUP),
    ("BYPASS_FILTER", 0),
    ("HALF_FRAMES", 0),
    ("REPEATS", 0),
    ("FRAMES", FRAMES),
    ("PARTITIONS", 1),
    ("PART.CHAN_1", 1),
    ("PART.NCHAN_1", NCHAN),
    ("DATE", "25-Jul-2026  09:00:00"),
    ("OPERATION", ""),
    ("AVERAGES", 0),
]
for i, (desc, unit) in enumerate(CHANNELS):
    c = "CHAN_%d" % (i + 1)
    lo, hi = limits[i]
    params += [
        ("DESC." + c, desc),
        ("UNITS." + c, unit),
        ("MAP." + c, desc),
        ("SCALE." + c, "1.000000E+000"),
        ("UPPER_LIMIT." + c, "%.6E" % hi),
        ("LOWER_LIMIT." + c, "%.6E" % lo),
    ]

nparams = len(params)
nblocks = (nparams * (PARAM_KEY_LEN + PARAM_VAL_LEN) + 511) // 512
params[1] = ("NUM_HEADER_BLOCKS", nblocks)
params[2] = ("NUM_PARAMS", nparams)

header = b"".join(param(k, v) for k, v in params)
header = header.ljust(nblocks * 512, b"\0")

# ------------------------------------------------- 5. interleave and write data
log("interleaving %d frames x %d channels" % (FRAMES, NCHAN))
FRAMES_PER_CHUNK = 512                       # 512 * 2048 * 10 * 4 B = 40 MB
srcs = [open(p, "rb") for p in tmp_paths]
os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
with open(OUT, "wb") as f:
    f.write(header)
    done = 0
    while done < FRAMES:
        nf = min(FRAMES_PER_CHUNK, FRAMES - done)
        nsamp = nf * PTS_PER_FRAME
        block = np.empty((nf, NCHAN, PTS_PER_FRAME), dtype=np.float32)
        for ic, src in enumerate(srcs):
            buf = np.fromfile(src, dtype=np.float32, count=nsamp)
            assert buf.size == nsamp
            block[:, ic, :] = buf.reshape(nf, PTS_PER_FRAME)
        block.tofile(f)
        done += nf
        if done % (FRAMES_PER_CHUNK * 4) == 0 or done == FRAMES:
            log("  %d / %d frames" % (done, FRAMES))
for src in srcs:
    src.close()
for p in tmp_paths:
    os.remove(p)

log("wrote %s  (%.1f MB)" % (OUT, os.path.getsize(OUT) / 1e6))
